//player 01
var randomNum1=Math.floor(Math.random() * 6) + 1;
//random image mapping
var randomimage1 ="images/Dice" + randomNum + ".png";
document.querySelectorAll("img") [0];
image1.setAttribute("src",randomImage1);
//player02
var randomNum2=Math.floor(Math.random()* 6) + 1;
var randomimage2 ="images/Dice" + randomNum1 + ".png";

var image2=document.querySelectorAll("img") [1];
image2.setAttribute("src",randomImage2);
//main logic-decide winner
if(randomNum1 > randomNum2)
{
    document.querySelector("h1").innerHTML="player 1 wins!";

}
else(randomNum2 > randomNum1)
{
    document.querySelector("h1").innerHTML="player 1 wins!";

}



